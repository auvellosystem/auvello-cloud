from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone

from .config import settings
from .models import Product


class Database:
    def __init__(self) -> None:
        self.conn = sqlite3.connect(settings.database_path)
        self.conn.row_factory = sqlite3.Row
        self._init()

    def _init(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_key TEXT NOT NULL,
                name TEXT NOT NULL,
                price REAL NOT NULL,
                original_price REAL,
                discount_percent REAL NOT NULL DEFAULT 0,
                captured_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_price_history_product
            ON price_history(product_key, captured_at);

            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_key TEXT NOT NULL,
                group_key TEXT NOT NULL,
                price REAL NOT NULL,
                discount_percent REAL NOT NULL,
                sent_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_notifications_product
            ON notifications(product_key, group_key, sent_at);

            -- V5: cooldown por PRODUCT de catálogo, não por anúncio/item.
            -- Isso impede que 10 vendedores do mesmo PS5 gerem 10 mensagens.
            CREATE TABLE IF NOT EXISTS product_notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                catalog_product_key TEXT NOT NULL,
                item_key TEXT,
                group_key TEXT NOT NULL,
                price REAL NOT NULL,
                discount_percent REAL NOT NULL,
                sent_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_product_notifications
            ON product_notifications(catalog_product_key, group_key, sent_at);
            """
        )
        self.conn.commit()

    @staticmethod
    def price_key(product: Product) -> str:
        """Histórico é por oferta/item, porque cada vendedor tem seu preço."""
        return product.item_id or product.product_id

    @staticmethod
    def notification_key(product: Product) -> str:
        """Publicação/cooldown é por PRODUCT de catálogo."""
        return product.product_id or product.item_id or ""

    # Compatibilidade com código antigo que eventualmente use Database.key().
    @staticmethod
    def key(product: Product) -> str:
        return Database.price_key(product)

    def record_price(self, product: Product) -> None:
        if product.price is None:
            return
        self.conn.execute(
            """INSERT INTO price_history
               (product_key, name, price, original_price, discount_percent, captured_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                self.price_key(product),
                product.name,
                product.price,
                product.original_price,
                product.discount_percent,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        self.conn.commit()

    def previous_price(self, product: Product) -> float | None:
        rows = self.conn.execute(
            """SELECT price FROM price_history
               WHERE product_key = ? ORDER BY id DESC LIMIT 2""",
            (self.price_key(product),),
        ).fetchall()
        if len(rows) < 2:
            return None
        return float(rows[1]["price"])

    def can_notify(self, product: Product, group_key: str) -> bool:
        since = (
            datetime.now(timezone.utc)
            - timedelta(hours=settings.cooldown_hours)
        ).isoformat()
        row = self.conn.execute(
            """SELECT 1 FROM product_notifications
               WHERE catalog_product_key = ?
                 AND group_key = ?
                 AND sent_at >= ?
               LIMIT 1""",
            (self.notification_key(product), group_key, since),
        ).fetchone()
        return row is None

    def mark_notified(self, product: Product, group_key: str) -> None:
        self.conn.execute(
            """INSERT INTO product_notifications
               (catalog_product_key, item_key, group_key, price,
                discount_percent, sent_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                self.notification_key(product),
                product.item_id,
                group_key,
                product.price or 0,
                product.discount_percent,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        self.conn.commit()
