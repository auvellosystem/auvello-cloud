#!/usr/bin/env bash
set -euo pipefail

PORT="${PORT:-3000}"
export PORT
# Python and Node live in the same Render Web Service.
export WHATSAPP_SERVICE_URL="http://127.0.0.1:${PORT}"

cleanup() {
  echo "[cloud] Encerrando processos..."
  kill "${NODE_PID:-}" "${PY_PID:-}" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

echo "[cloud] Iniciando WhatsApp/Baileys na porta ${PORT}..."
node whatsapp-service/index.js &
NODE_PID=$!

# Give Express a moment to open the local /health and /send routes.
sleep 3

echo "[cloud] Iniciando Auvello Python. Intervalo controlado por CHECK_INTERVAL_MINUTES."
python3 main.py &
PY_PID=$!

# If either process exits, stop the service so Render restarts it.
wait -n "$NODE_PID" "$PY_PID"
STATUS=$?
echo "[cloud] Um processo principal encerrou (status ${STATUS})."
exit "$STATUS"
