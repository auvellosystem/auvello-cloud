import argparse
import time

from app.auth import authorize_interactively
from app.config import settings
from app.service import AuvelloService


def main() -> None:
    parser = argparse.ArgumentParser(description="Auvello v2")
    parser.add_argument("--auth", action="store_true", help="Refaz OAuth do Mercado Livre")
    parser.add_argument("--once", action="store_true", help="Executa uma rodada e encerra")
    args = parser.parse_args()

    if args.auth:
        authorize_interactively()
        print("Autorizacao concluida.")
        return

    service = AuvelloService()
    if args.once:
        service.run_once()
        return

    while True:
        try:
            service.run_once()
        except KeyboardInterrupt:
            print("\nEncerrado pelo usuario.")
            return
        except Exception as exc:
            print(f"[ciclo] erro geral: {exc}")
        print(f"Proxima rodada em {settings.check_interval_minutes} min.")
        time.sleep(max(1, settings.check_interval_minutes) * 60)


if __name__ == "__main__":
    main()
